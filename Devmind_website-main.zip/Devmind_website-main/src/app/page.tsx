import React from "react";
import Slider from "@/app/component/Slider";
const Home = () => {
  return (
    <div>
      <Slider />
    </div>
  );
};

export default Home;
